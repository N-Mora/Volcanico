package com.nimora.Volcan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VolcanApplication {

	public static void main(String[] args) {
		SpringApplication.run(VolcanApplication.class, args);
	}
}
